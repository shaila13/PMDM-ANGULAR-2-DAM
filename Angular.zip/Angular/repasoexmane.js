'use strict'

// Durations are in minutes

var tasks = [

    {
        'name': 'Write for Envato Tuts+',
        'duration': 120
    },
    {
        'name': 'Work out',
        'duration': 60
    },
    {
        'name': 'Procrastinate on Duolingo',
        'duration': 240
    }

];

var task_names = tasks.map(function (task, index, array) {
    return task.name;
});

console.log(task_names);
//Arrow function permiten omitir la palabra return cuando el código es de una sola línea. 
var task_duration = tasks.map((task) => task.duration);

console.log(task_duration);

//FILTER
//Usando forEach, escribiríamos:

var difficult_tasks = [];

tasks.forEach(function (task) {
    if (task.duration >= 120) {
        difficult_tasks.push(task);
    }
});
console.log(difficult_tasks);


//Usando filter, escribiríamos:

difficult_tasks = tasks.filter(task => task.duration >= 120);

console.log(difficult_tasks);

//Reducción de Arrays

/**
 * Map crea una nueva array mediante la transformación de cada elemento en una array, 
 * de forma individual. filter crea una nueva matriz eliminando los elementos que no pertenecen. 
 * Reduce, por otro lado, toma todos los elementos en un array, y los reduce en un solo valor.
 */

var numbers = [1, 2, 3, 4, 5],
    total = 0;

//Método pa tontos
numbers.forEach(function (number) {
    total += number;
});

var total = [1, 2, 3, 4, 5].reduce(function (previous, current) {
    return previous + current;
}, 0);
console.log(total);

//No va
var total_time = tasks.reduce(function (previous, current) {
    return previous + current;

}, 0);

var total_time = tasks.reduce((previous, current) => previous + current);
console.log("prueba");
console.log(total_time);

//Multiply all the values in array with a specific number:
var numbers = [65, 44, 12, 4];


var numbers_multiplicacion = numbers.map(function (numbers, index, array) {
    return numbers * 10;
});

var task_duration = tasks.map((task) => task.duration);
var numbers_multiplicacion_flecha = numbers.map((numbers) => numbers * 10);

console.log(numbers_multiplicacion);
console.log(numbers_multiplicacion_flecha);

//Get the sum of the numbers in the array:
var numbers_multiplicacion_reduce = numbers.reduce(function (previous, current) {
    return previous + current;
}, 0);
console.log(numbers_multiplicacion_reduce);
//Round all the numbers in an array, and display the sum:
var numbersto = [15.5, 2.3, 1.1, 4.7];

var numbersRoundReduce = numbersto.reduce(function (previous, current) {
    return Math.round(previous + current);
}, 0);

console.log(numbersRoundReduce);
//Get the full name for each person in the array:
var persons = [
    { firstname: "Malcom", lastname: "Reynolds" },
    { firstname: "Kaylee", lastname: "Frye" },
    { firstname: "Jayne", lastname: "Cobb" }
];

var person_full_name = persons.map((name) => name.firstname + " " + name.lastname);
console.log(person_full_name);

//Filter 
//Return an array of all the values in the ages array that are 18 or over:
var ages = [32, 33, 16, 40];

var mayores_edad = ages.filter(mayoria_edad => mayoria_edad >= 18);

console.log(mayores_edad);

//Every
//Check if ALL the values in the ages array are 18 or over:
var mayores_edad_every = ages.every(mayoria_edad => mayoria_edad >= 18);
console.log(mayores_edad_every);

//Check if all the answer values in the array are the same:

var survey = [
    { name: "Steve", answer: "Yes" },
    { name: "Jessica", answer: "Yes" },
    { name: "Peter", answer: "Yes" },
    { name: "Elaine", answer: "Yes" }
];

var survey_true = survey.every(surveys => surveys.answer === "Yes");
console.log(survey_true);

//Fill all the array elements with a static value:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.fill("Kiwi");
console.log(fruits);

/**
 * array.fill(value, start, end)
 * value --> Required. The value to fill the array with,
 * start --> Optional. The index to start filling the array (default is 0)
 * end --> Optional. The index to stop filling the array (default is array.length)
 */
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.fill("Kiwi", 2, 4); console.log(fruits);

//Get the index of the first element in the array that has a value of 18 or more:
var ages = [3, 10, 18, 20];
var mayores_edad_bis = ages.findIndex(mayoria_edad => mayoria_edad >= 18);
console.log(mayores_edad_bis);

//Create an Array from a String:
var myArr = Array.from("ABCDEFG"); console.log(myArr);

//Check if an array includes "Mango":
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var n = fruits.includes("Mango"); console.log(n);
//Check if an array includes "Banana", starting the search at position 3:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var n = fruits.includes("Banana", 3); console.log(n);

//Search an array for the item "Apple":
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var a = fruits.indexOf("Apple");

//Search an array for the item "Apple", starting the search at position 4:
var fruits = ["Banana", "Orange", "Apple", "Mango", "Banana", "Orange", "Apple"];
var a = fruits.indexOf("Apple", 4);

//Check whether an object is an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(Array.isArray(fruits));

//Join the elements of an array into a string:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var energy = fruits.join(); console.log(energy);

//Create an Array Iterator object, with keys for each item in the fruit array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var x = fruits.keys();
console.log(x.next().value);//bien sale 0 en 3wwschool

//Return the length of an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.length;
//Search an array for the item "Apple":
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var a = fruits.lastIndexOf("Apple");
//Search an array for the item "Apple", starting the search at position 4:

var a = fruits.lastIndexOf("Apple", 4);

//Remove the last element of an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.pop();

//Make a new array method that transforms array values into upper case:
Array.prototype.myUcase = function () {
    for (i = 0; i < this.length; i++) {
        this[i] = this[i].toUpperCase();
    }
};

// Make an array, then call the myUcase method:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.myUcase(); 

//Add a new item to an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.push("Kiwi"); 
//Select elements from an array:
var fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
var citrus = fruits.slice(1, 3);
//Sort an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.sort();
//Add items to the array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.splice(2, 0, "Lemon", "Kiwi");

//Reverse the order of the elements in an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.reverse();

//Convert an array to a string:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.toString();
//Add new items to the beginning of an array:
var fruits = ["Banana", "Orange", "Apple", "Mango"];
fruits.unshift("Lemon","Pineapple");

//valueOf() is the default method of the array object.
var fruits = ["Banana", "Orange", "Apple", "Mango"];
var v = fruits.valueOf();
console.log(v);
 //fruits.valueOf() will return the same as fruits