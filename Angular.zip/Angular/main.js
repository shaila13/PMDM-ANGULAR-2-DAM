var Main = /** @class */ (function () {
    function Main() {
        console.log("Aplicación JS cargada!!");
    }
    return Main;
}());
var main = new Main();
