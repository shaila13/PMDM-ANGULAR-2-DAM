import { Camiseta } from './Camiseta';

class Main{
	constructor(){ 
	console.log("Aplicación JS cargada!!");
	}

}

var main = new Main();