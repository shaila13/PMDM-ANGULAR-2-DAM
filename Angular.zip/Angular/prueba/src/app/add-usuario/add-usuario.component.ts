import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Usuario } from '../modelo/usuario';

@Component({
  selector: 'app-add-usuario',
  templateUrl: './add-usuario.component.html',
  styleUrls: ['./add-usuario.component.css']
})
export class AddUsuarioComponent implements OnInit {

  nombreUsuario:string;
  apellidosUsuario:string;
  edadUsuario:number;
  trabaja:boolean;

  @Output() salidaUsuario = new EventEmitter<Usuario>();

  constructor() { }

  ngOnInit() {
  }

  addUsuario(){
    let usuarioMio = new Usuario(this.nombreUsuario, this.apellidosUsuario, this.edadUsuario,this.trabaja);
    this.salidaUsuario.emit(usuarioMio);
  }

}
