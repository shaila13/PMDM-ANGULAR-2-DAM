import { Component, OnInit } from '@angular/core';
import { Usuario } from '../modelo/usuario';
import { Router } from '@angular/router';
import { ServicioUsuariosService } from '../servicio-usuarios.service';

@Component({
  selector: 'app-lista-usuarios',
  templateUrl: './lista-usuarios.component.html',
  styleUrls: ['./lista-usuarios.component.css']
})
export class ListaUsuariosComponent implements OnInit {
  //private listaUsuarios: Array<string>;  // igual que []<string>
  private listaUsuarios: Array<Usuario>; 
  
  constructor(private _router:Router, private _servicioUsuarios: ServicioUsuariosService) { }
    
  
    ngOnInit() {
      this.listaUsuarios = this._servicioUsuarios.getUsuarios();
    }

    borrarUsuario(nombre:string){
      let indice:number=this.listaUsuarios.findIndex(u => u.nombre===nombre);
      if(indice !== -1){
        this.listaUsuarios.splice(indice, 1)
      }
  }

  anhadirUsuario(usuario:Usuario){
   this.listaUsuarios.push(usuario);     
  }

  irUsuario(usuario:Usuario){
    let ruta='/usuarios/'+usuario.nombre+' **** '+usuario.edad;
    this._router.navigateByUrl(ruta);
  }

}
