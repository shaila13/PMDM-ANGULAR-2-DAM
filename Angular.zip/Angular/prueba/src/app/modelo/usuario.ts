export class Usuario {
    nombre: string;
    apellidos: string;
    edad: number;
    trabaja: boolean;

    constructor (nombre: string, apellidos: string, edad: number,trabaja: boolean){
            this.nombre = nombre;
            this.apellidos  =apellidos;
            this.edad = edad;
            this.trabaja=trabaja;
        }

    // En modo abreviado (declaro atributos y constructor a la vez 2x1):
    // constructor(public nombre: string,
    //     apellidos: string,
    //     edad: number){}
    
}
