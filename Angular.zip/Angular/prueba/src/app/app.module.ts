import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HelloWorldComponent } from './hello-world/hello-world.component';
import { ListaUsuariosComponent } from './lista-usuarios/lista-usuarios.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UsuarioComponent } from './usuario/usuario.component';
import { AddUsuarioComponent } from './add-usuario/add-usuario.component';
import { DetallesUsuarioComponent } from './detalles-usuario/detalles-usuario.component';
import { ServicioUsuariosService } from './servicio-usuarios.service';

@NgModule({
  declarations: [             // componentes
    AppComponent,
    HelloWorldComponent,
    ListaUsuariosComponent,
    UsuarioComponent,
    AddUsuarioComponent,
    DetallesUsuarioComponent
  ],
  imports: [                  // módulos
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule
  ],
  providers: [],
  // providers: [ServicioUsuariosService],   // Old Way: servicios propios (creados por nosotros)
  bootstrap: [AppComponent]               // componente con el que arranca
})
export class AppModule { }
