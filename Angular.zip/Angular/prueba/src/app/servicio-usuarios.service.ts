import { Injectable } from '@angular/core';
import { Usuario } from './modelo/usuario';

const LISTA_USUARIOS: Usuario[] = [
  new Usuario ("María", "Pérez", 45,true),
  new Usuario ("Lucas", "López", 34,false),
  new Usuario ("Pedro", "Gónzález", 23,true),
  new Usuario ("Sara", "García", 68,false)

]
@Injectable({
  providedIn: 'root'
})
export class ServicioUsuariosService {

  constructor() { }

getUsuarios(){
  return LISTA_USUARIOS;
}

getUsuario(nombre: string): Usuario {
  return LISTA_USUARIOS.find(u => u.nombre === nombre);
}

addUsuario(usuario: Usuario){
  return LISTA_USUARIOS.push(usuario);
}

}
