import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Usuario } from '../modelo/usuario';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {
  @Input() miUsuario:Usuario;  // creo la variable miUsuario y le digo que los datos vienen de fuera con @Input()
  @Output() borrar = new EventEmitter();

  constructor() { }


  ngOnInit() {
  }

  avisarBorrar(){
    this.borrar.emit();
  }

}
