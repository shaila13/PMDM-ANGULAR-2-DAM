import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detalles-usuario',
  templateUrl: './detalles-usuario.component.html',
  styleUrls: ['./detalles-usuario.component.css']
})
export class DetallesUsuarioComponent implements OnInit {
  informacionUsuario: string;

  // Hace falta meterle el parámetro (por el que se va a preguntar desde)
  constructor(private _route: ActivatedRoute) { }

  ngOnInit() {                                                            // el parámetro del get es el indicado en routes tras ':'
    this.informacionUsuario = this._route.snapshot.paramMap.get('info');  // devuelve un string (con un '+' tras el '=' devuelve un int)
  }

}
