import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AddUsuarioComponent } from './add-usuario/add-usuario.component';
import { ListaUsuariosComponent } from './lista-usuarios/lista-usuarios.component';
import { DetallesUsuarioComponent } from './detalles-usuario/detalles-usuario.component';

const routes: Routes = [
  //rutas
  {path:'', redirectTo:'home', pathMatch:'full'},
  {path:'home', component:ListaUsuariosComponent},
  {path:'usuarios', component:ListaUsuariosComponent},
  {path:'add-usuario', component:AddUsuarioComponent},
  {path:'usuarios/:info', component:DetallesUsuarioComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
