'use strict'

var contactos = [
{
  cod: 1,
  nombre: 'Inés',
  apellidos: 'García',
  foto: '/ruta/img.jpg',
  edad: 28,
  dirección: 'C/Rue del Percebe, 3',
  ciudad: 'Oviedo',
  tfno: '985 23 23 23',
  email: 'inesgf@gmail.com',
  hijos: true,
  sexo: 'femenino',
  intereses: [
    {
      nombre: 'fiesta',
      descripcion: 'me encanta salir de fiesta por la noche',
      importancia: 7
    },
    {
      nombre: 'deporte',
      descripción: 'practico atletismo desde los 9 años; la especialidad de Cross',
      importancia: 3
    },
    {
      nombre: 'música',
      descripción: ' me encanta la música, siempre estoy escuchando música, esté donde esté',
      importancia: 4
    }
  ],
  votos: 3,
},

{
  cod: 2,
  nombre: 'Juan',
  apellidos: 'Pérez',
  foto: '/ruta/img.jpg',
  edad: 38,
  dirección: 'C/Rue del Percebe, 44',
  ciudad: 'Gijón',
  tfno: '985 111111',
  email: 'juan@gmail.com',
  hijos: true,
  sexo: 'masculino',

  intereses: [
    {
      nombre: 'videojuegos',
      descripcion: 'me encanta jugar',
      importancia: 9
    },
    {
      nombre: 'deporte',
      descripción: 'practico fútbol',
      importancia: 8
    },
    {
      nombre: 'comer',
      descripción: ' me encanta comer',
      importancia: 5
    },
    {
      nombre: 'música',
      descripción: 'oir música',
      importancia: 4
    }
  ],
  votos: 3,
  }
];

var api = {

  getModificarIntereses: function (numero,contactos) {
     return new Promise((resolve, reject) => {
      contactos.forEach(contacto => {
       contacto.intereses.forEach(interes => {
     
          if (interes.importancia < numero) {
           interes.importancia=0;
          }
      });

    });  
    resolve(contactos);

      return reject(new Error('No se puede realizar lo indicado.'));
    });

  }
};

api.getModificarIntereses(4,contactos)
  .then(contactos => console.log(contactos))
  .catch(error => console.error(error));


