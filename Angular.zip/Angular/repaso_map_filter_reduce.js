'use strict'

//MAP
// What you have
var officers = [
    { id: 20, name: 'Captain Piett' },
    { id: 24, name: 'General Veers' },
    { id: 56, name: 'Admiral Ozzel' },
    { id: 88, name: 'Commander Jerjerrod' }
];

// What you need -->   [20, 24, 56, 88]

var officers_id = officers.map(function (officer, index, array) {
    return officer.id;
});

console.log(officers_id);
//Arrow function permiten omitir la palabra return cuando el código es de una sola línea. 
var officers_id_flecha = officers.map(officer => officer.id);

console.log(officers_id_flecha);

//REDUCE

var pilots = [
    {
        id: 10,
        name: "Poe Dameron",
        years: 14,
    },
    {
        id: 2,
        name: "Temmin 'Snap' Wexley",
        years: 30,
    },
    {
        id: 41,
        name: "Tallissan Lintra",
        years: 16,
    },
    {
        id: 99,
        name: "Ello Asty",
        years: 22,
    }
];
console.log("We need to know the total years of experience of all of them.");
var total_time = pilots.reduce(function (accumulator, pilot) {
    return accumulator + pilot.years;
}, 0);

console.log(total_time);

console.log("Flecha.");
const totalYears = pilots.reduce((acc, pilot) => acc + pilot.years, 0);
console.log(totalYears);


console.log("Now let’s say I want to find which pilot is the most experienced one.");
var mostExpPilot = pilots.reduce(function (oldest, pilot) {
    return (oldest.years || 0) > pilot.years ? oldest : pilot;
}, {

});
console.log(mostExpPilot);

//FILTER

const rebels = pilots.filter(pilot => pilot.faction === "Rebels");
const empire = pilots.filter(pilot => pilot.faction === "Empire");

//Combining .map(), .reduce(), and .filter()


var personnel = [
  {
    id: 5,
    name: "Luke Skywalker",
    pilotingScore: 98,
    shootingScore: 56,
    isForceUser: true,
  },
  {
    id: 82,
    name: "Sabine Wren",
    pilotingScore: 73,
    shootingScore: 99,
    isForceUser: false,
  },
  {
    id: 22,
    name: "Zeb Orellios",
    pilotingScore: 20,
    shootingScore: 59,
    isForceUser: false,
  },
  {
    id: 15,
    name: "Ezra Bridger",
    pilotingScore: 43,
    shootingScore: 67,
    isForceUser: true,
  },
  {
    id: 11,
    name: "Caleb Dume",
    pilotingScore: 71,
    shootingScore: 85,
    isForceUser: true,
  },
];

console.log("Get the total score of force users only");

var resultado = personnel.filter(forceUser => forceUser.isForceUser).map(function (jedi) {
    return jedi.pilotingScore + jedi.shootingScore;
  }).reduce(function (acc, score) {
    return acc + score;
  }, 0);
console.log(resultado);

//And look how pretty it is with arrow functions:
const totalJediScore = personnel.filter(person => person.isForceUser)
.map(jedi => jedi.pilotingScore + jedi.shootingScore)
.reduce((acc, score) => acc + score, 0);

var lista=[1,2,3,4];
 
var resultado1= lista.reduce(function(total,valor) {

  return total+valor;

})
console.log (resultado1);

//Contar la cantidad de nombres repetidos en un aula de clase.

const nombres = [
    'Jorge','Maria','Jose',
    'Bob','Pat','Maria',
    'Jose','Jose'
];

const cantidadNombres = nombres.reduce((contadorNombres,nombre)=>{
contadorNombres[nombre] = (contadorNombres[nombre] || 0)+1;

return contadorNombres;
},{});

console.log(cantidadNombres);

//Cuadrados
let numbers = [1, 2, 3, 4, 5, 6]
let numSqrt =  numbers.map(function (number) {
    return number*number;
});
//Con flecha

let numSqrts =numbers.map( number =>  number*number);
// [1, 4, 9, 16, 25, 36]
console.log("flecha " +numSqrts);
//reduce total

let totales= numbers.reduce(function(anterior,posterior) {
  return anterior+posterior;

})
//reduce flecha
let total = numbers.reduce((prev, cur) => prev + cur, 0)

var developers = [
  { name: 'Tano', type: 'mobile', age: 4 },
  { name: 'Inma', type: 'mobile', age: 31 },
  { name: 'Edgar', type: 'web', age: 35 },
  { name: 'Fernando', type: 'mobile', age: 33 }
];

//sacar el total de las edades de los desarrolladores mobile

let totalEdadMobile = developers.filter(tipo => tipo.type==='mobile').map(edad => edad.age).reduce((prev, cur) => prev + cur, 0);

console.log(totalEdadMobile);

var arreglo = [4,2,5,6,77,844,432]; //Con este arreglo trabajaremos

//Promedio

var arreglo = [4,2,5,6,77,844,432]; //Con este arreglo trabajaremos
var sumatoria = arreglo.reduce(function(a, b){
  return a + b; //Regresa el acumulador más el siguiente
}, 0); //Pero si no encuentras nada o no hay siguiente, regresa 0
var promedios = sumatoria / arreglo.length;

var promedio = arreglo.reduce((previo, actual) => previo + actual) / arreglo.length;

console.log(promedio);

//Sumatoria con objetos sacar la sumatoria edad
var arregloObjetos = [
  {
    nombre: "John Doe",
    edad: 50
  },
  {
    nombre: "Pedro",
    edad: 20
  },
  {
    nombre: "Juanita",
    edad: 22
  }
];

var edad = arregloObjetos.map(edad => edad.edad).reduce((prev, cur) => prev + cur, 0);
console.log("Edad "+edad);

//Sacar el promedio redondeando
var edadPromedio = Math.ceil(arregloObjetos.map(edad => edad.edad).reduce((prev, cur) => prev + cur, 0) / arregloObjetos.length);
console.log("Edad edadPromedio "+edadPromedio);

//Otra forma
var sumatoriaObjeto = arreglo.reduce(function(acumulador, siguienteValor){
  return {
    edad: acumulador.edad + siguienteValor.edad
  };
}, {edad: 0}); //Si no hay nada, regresamos un objeto con edad = 0. No hay necesidad de devolver el nombre, pues no es necesario

var sumatoriaObjeto = arreglo.reduce(function(acumulador, siguienteValor){
  return {
    edad: acumulador.edad + siguienteValor.edad
  };
}, {edad: 0}); //Si no hay nada, regresamos un objeto con edad = 0. No hay necesidad de devolver el nombre, pues no es necesario
 
var promedioEdad = sumatoriaObjeto.edad / arreglo.length;

const myArray = [-9, 9, 10, 1, -12, 12, 5, 29, 8, 12, -5];
//Función para determinar si un número es par y positivo.

var parPositivo= myArray.filter(num => num > 0 && (num%2===0));
console.log(parPositivo);

//El cliente ha introducido un cupón de descuento y debemos de hacerle un descuento del 10% en cada reserva
const bookings = [
  {id:23453, price: 250, room: 'standard', prepaid: false, succeeded: true},
  {id:56456, price: 150, room: 'superior', prepaid: false, succeeded: true},
  {id:43243, price: 550, room: 'standard', prepaid: true, succeeded: false},
  {id:23223, price: 550, room: 'standard', prepaid: true, succeeded: true},
  {id:89232, price: 650, room: 'superior', prepaid: true, succeeded: false},  
];

const discount = 10;
const discountedBookings = bookings.map(booking => ({...booking, price: booking.price * (1 - (discount / 100))
}));
//Los puntos suspensivos en booking es porque le pasamos varios objetos
console.log(discountedBookings);
//Vamos a sumar el total de € de las reservas que hay en el array:
const totalPrice =  bookings.map(precio => precio.price).reduce((prev, cur) => prev + cur, 0);

console.log(totalPrice);

var foo = [ 'En', 'un', 'lugar', 'de', 'la', 'Mancha' ];
 
console.info( ...foo );
// En un lugar de la Mancha

/*Estamos cogiendo nuestro array para procesar cada uno de sus elementos como 
argumentos de la propia función ‘console.info’, por lo que el resultado sería equivalente a escribir:
*/
console.info( foo[ 0 ], foo[ 1 ], foo[ 2 ], foo[ 3 ], foo[ 4 ], foo[ 5 ] );

var foo = [ 'En', 'un', 'lugar', 'de', 'la', 'Mancha' ],
    bar = [ 'de', 'cuyo', 'nombre', 'no', 'quiero', 'acordarme' ],
 
    // Old Style
    oldStyle = foo.concat( bar ),
 
    // ECMAScript 6 style
    ES6Style = [ ...foo, ...bar ];
 
console.info( oldStyle );
/*[ "En", "un", "lugar", "de", "la", "Mancha", "de", 
    "cuyo", "nombre", "no", "quiero", "acordarme" ]*/
 
console.info( ES6Style );
/* [ "En", "un", "lugar", "de", "la", "Mancha", "de", 
    "cuyo", "nombre", "no", "quiero", "acordarme" ]*/

    var saveBook = function ( title, author, publisher ) {
    /* Awesome logic goes here... */
    console.info( 
        'The book ', title, 
        ' by ', author, 
        ' published by ', publisher, 
        ' has been added to database!' 
    );
}
 
var book1 = [ 'JavaScript: The Good Parts', 'Douglas Crockford', 'OReilly' ],
    book2 = [ 'JavaScript: The Definitive Guide', 'David Flanagan', 'OReilly' ];
 
saveBook( ...book1 );
// The book JavaScript: The Good Parts by Douglas Crockford 
// published by OReilly has been added to database!
 
saveBook( ...book2 );
// The book JavaScript: The Definitive Guide by David Flanagan
// published by OReilly has been added to database!

//Si pasamos más elementos en el array de los que espera la función, no ocurre ningún error:

var book3 = [ 'Eloquent JavaScript', 'Marijn Haverbeke', 
    'No Starch Press', '2011', 'English' ];
 
saveBook( ...book3 );
// The book Eloquent JavaScript by Marijn Haverbeke 
// published by No Starch Press has been added to database!

//Si por el contrario omitimos valores, el intérprete Javascript los reemplazará por ‘undefined’, pero no lanzará un mensaje de error:

var book4 = [ 'JavaScript Patterns' ];
 
saveBook( ...book4 );
// The book JavaScript Patterns by undefined 
// published by undefined has been added to database!
/*var foo = { foo: 'Hello World', bar: 'Goodbye Lenin' };
console.info( ...foo );
// TypeError: foo is not iterable*/

// palabra reservada let, la cual nos permite declarar variables locales

/*
function processValue (value: number | (() => number) ) {

var x = typeof value !== "number" ? value() : value;

}
*/