export class Usuario {
}
