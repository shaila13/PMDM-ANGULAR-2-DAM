import { Component, OnInit } from '@angular/core';
import { Task } from '../task';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
//Cada tarea será un objeto JSON con los atributos: id, title y pending(puede ser true o false)
 private tasks: Task[];
  constructor() {
	this.tasks= [{ id:1, title:'Tarea 1', pending:false},
				 { id:2, title:'Tarea 2', pending:true},
				 { id:3, title:'Tarea 3', pending:false}
				];
   }

  ngOnInit() {
  }

}
