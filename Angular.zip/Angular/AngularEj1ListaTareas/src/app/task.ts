export interface Task {
    id: number;
    title: string;
    pending: boolean;
}
