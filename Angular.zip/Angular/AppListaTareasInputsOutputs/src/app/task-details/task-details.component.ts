import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Task } from '../task';
@Component({
  selector: 'app-task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.css']
})
export class TaskDetailsComponent implements OnInit {
@Input() task:Task;
@Output() deleted = new EventEmitter<Task>();
  constructor() { }

  ngOnInit() {
  }
	deleteTask() {
		this.deleted.emit(this.task);
  	}
}
