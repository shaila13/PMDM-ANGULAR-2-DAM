import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
@Component({
  selector: 'app-tasks-list',
  templateUrl: './tasks-list.component.html',
  styleUrls: ['./tasks-list.component.css']
})
export class TasksListComponent implements OnInit {

//Cada tareaserá un objeto JSON con los atributos: id, title y pending(puede ser true o false)
 private tasks: Task[];
  constructor() {
	this.tasks= [{ id:1, title:'Tarea 1', pending:false},
				 { id:2, title:'Tarea 2', pending:true},
				 { id:3, title:'Tarea 3', pending:false}
				];
   }

  ngOnInit() {
  }
  deleteTask(task: Task) {
    this.tasks.splice(this.tasks.findIndex(t => task.id === t.id), 1);
  }
}
