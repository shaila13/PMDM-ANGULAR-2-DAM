export var Configuracion = {
	color: "red",
	fondo: "#eee",
	titulo: "Master en JavaScript y Angular",
	descripcion: "Aprendiendo Angular con Víctor Robles - victorroblesweb"
};