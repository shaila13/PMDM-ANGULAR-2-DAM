console.log("Hola Mundo con TypeScript");
alert("Hola Mundo con TS con Víctor Robles Web");
