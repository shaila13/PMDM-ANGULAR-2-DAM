
function getNumero(numero:number = 12):string{
	return "El numero es: "+numero;
}

console.log(getNumero(55));