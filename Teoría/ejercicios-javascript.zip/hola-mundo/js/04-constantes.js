"use strict"

// Constantes
// Como una variable, pero su valor no puede cambiar

var web = "https://victorroblesweb.es";
const ip = "192.88.0.12";

web = "https://victorroblescursos.es";

console.log(web, ip);