'use strict'

// VARIABLES
// Una variable es un contenedor de información

var pais = "España";
var continente = "Europa";
var antiguedad = 2019;
var pais_y_continente = pais+' '+continente;

pais = "Mexico";
continente = "Latinoamerica";

console.log(pais, continente, antiguedad);
alert(pais_y_continente);
