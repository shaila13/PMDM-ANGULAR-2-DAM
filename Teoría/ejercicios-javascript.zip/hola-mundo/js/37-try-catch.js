
try{
	var year = 2019;
	alert(year);
	var vector = new Array(99999999999999999);

}catch(error){
	console.log(error)
	alert("A ocurrido un error en el código");
}
