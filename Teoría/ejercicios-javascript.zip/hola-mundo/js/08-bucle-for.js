'use strict'

// Bucle FOR
// Bucle es una estructura de control que se repite varias veces

var numero = 100;

for(var i = 0; i <= numero; i++){
	console.log("Vamos por el numero: "+i);

	// debugger;
}