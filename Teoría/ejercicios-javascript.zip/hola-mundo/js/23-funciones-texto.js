'use strict'

// Transformacion de textos
var numero = 444;
var texto1 = "   Bienvenido al curso de JavaScript curso de Victor Robles   ";
var texto2 = "es muy buen curso";

var busqueda = texto1.trim();
console.log(busqueda);