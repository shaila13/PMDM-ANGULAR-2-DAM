'use strict'

// Operadores
var numero1 = 7;
var numero2 = 12;
var operacion = numero1 * numero2;

alert("Es resultado de la operación es: "+operacion);


// Tipos de datos
var numero_entero = 44;
var cadena_texto = 'Hola "que" tal';
var verdadero_o_falso = false;
var numero_falso = "33.4";

console.log(typeof numero_entero);
console.log(typeof cadena_texto);
console.log(typeof verdadero_o_falso);
console.log(typeof numero_falso);


