'use strict'

// ALERTA
// alert("Esta es mi alerta!!");
// alert("Este es mi texto");

// CONFIRMACIÓN
//var mi_resultado = confirm("¿Estas seguro de querer continuar?");
//console.log(mi_resultado);

// INGRESO DATOS
var mi_resultado = prompt("¿Que edad tienes?", 18);
console.log(typeof mi_resultado);